#!/bin/bash





sudo apt install bastet

bastet
